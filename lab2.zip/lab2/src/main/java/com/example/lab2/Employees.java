package com.example.lab2;

public class Employees {
    private int ID;
    private String Name;
    private String Address;
    private int Salary;
    public Employees(int ID, String Name, String Address, int Salary) {
        this.ID = ID;
        this.Name = Name;
        this.Address = Address;
        this.Salary = Salary;
    }
    public int getID() {
        return ID;
    }
    public String getName() {
        return Name;
    }
    public String getAddress() {
        return Address;
    }
    public int getSalary() {
        return Salary;
    }
}
